class UtilDomain {
	String name

}
