class UtilDomainController {

    def scaffold = UtilDomain
}
