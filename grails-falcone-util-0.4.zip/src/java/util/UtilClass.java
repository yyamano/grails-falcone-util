package util;


/**
 * Created by IntelliJ IDEA.
 * User: eric
 * Date: Jan 22, 2009
 * Time: 7:08:15 AM
 */
public class UtilClass {
}
