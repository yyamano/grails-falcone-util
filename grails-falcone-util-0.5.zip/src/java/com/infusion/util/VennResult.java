package com.infusion.util;

/**
 * Created by IntelliJ IDEA.
 * User: nolan.white
 * Date: Aug 1, 2008
 * Time: 10:51:47 AM
 *
 */
public enum VennResult {
        A, B, OK
    }