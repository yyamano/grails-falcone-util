package com.infusion.util.factory;

/**
 * Created by IntelliJ IDEA.
 * User: eric
 * Date: Dec 18, 2008
 * Time: 3:06:03 PM
 */
public interface GenericFactory<T> {
    T create();
}
