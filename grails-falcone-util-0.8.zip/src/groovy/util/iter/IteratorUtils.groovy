package util.iter
/**
 * Created by IntelliJ IDEA.
 * User: eric
 * Date: Feb 13, 2009
 * Time: 1:57:05 PM
 */
public class IteratorUtils {

  public static Iterator iterateMap(Collection collection, Closure key, Closure value) {

  }

  public static Iterator treeIterator(Collection collection) {

  }




}